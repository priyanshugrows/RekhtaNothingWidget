package com.rekhta.nothingwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.widget.RemoteViews;
import java.time.LocalDate;
import java.time.ZoneId;

public class SherWidgetProvider extends AppWidgetProvider {
    private static final String PREFS = "rekhta_widget";
    private static final String ACTION_NEXT = "com.rekhta.nothingwidget.NEXT_SHER";
    private static final String ACTION_PREV = "com.rekhta.nothingwidget.PREV_SHER";

    private static final Sher[] SHERS = new Sher[] {
        new Sher("दिल ना-उम्मीद तो नहीं, नाकाम ही तो है\nलम्बी है ग़म की शाम मगर शाम ही तो है",
            "Dil naa-umeed to nahin, nakaam hi to hai\nLambi hai gham ki shaam magar shaam hi to hai",
            "फ़ैज़ अहमद फ़ैज़", "https://www.rekhta.org/couplets/dil-naa-umiid-to-nahiin-naakaam-hii-to-hai-faiz-ahmad-faiz-couplets"),
        new Sher("रंज से ख़ूगर हुआ इंसाँ तो मिट जाता है रंज\nमुश्किलें मुझ पर पड़ीं इतनी कि आसाँ हो गईं",
            "Ranj se khuugar hua insaan to miT jaata hai ranj\nMushkilein mujh par paRiin itni ki aasaan ho gayin",
            "मिर्ज़ा ग़ालिब", "https://www.rekhta.org/archives/2020-03-06/All/"),
        new Sher("सोचो तो सिलवटों से भरी है तमाम रूह\nदेखो तो इक शिकन भी नहीं है लिबास में",
            "Socho to silwaTon se bhari hai tamaam rooh\nDekho to ik shikan bhi nahin hai libaas mein",
            "शकेब जलाली", "https://www.rekhta.org/authors/shakeb-jalali/"),
        new Sher("कोशिश भी कर, उम्मीद भी रख, रास्ता भी चुन\nफिर इस के बाद थोड़ा मुक़द्दर तलाश कर",
            "Koshish bhi kar, ummeed bhi rakh, raasta bhi chun\nPhir is ke baad thoRa muqaddar talaash kar",
            "निदा फ़ाज़ली", "https://www.rekhta.org/archives/2024-01-06/TopFive/"),
        new Sher("और भी दुख हैं ज़माने में मोहब्बत के सिवा\nराहतें और भी हैं वस्ल की राहत के सिवा",
            "Aur bhi dukh hain zamaane mein mohabbat ke siwa\nRaahatein aur bhi hain wasl ki raahat ke siwa",
            "फ़ैज़ अहमद फ़ैज़", "https://www.rekhta.org/translators/faiz-ahmad-faiz/couplets")
    };

    private static class Sher {
        final String devanagari, roman, poet, url;
        Sher(String d, String r, String p, String u) { devanagari=d; roman=r; poet=p; url=u; }
    }

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        ensureDay(context);
        for (int id : ids) render(context, manager, id);
    }

    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (context == null || intent == null) return;
        String action = intent.getAction();
        if (ACTION_NEXT.equals(action) || ACTION_PREV.equals(action)) {
            SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            ensureDay(context);
            int index = p.getInt("index", 0);
            index = ACTION_NEXT.equals(action) ? (index + 1) % SHERS.length : (index + SHERS.length - 1) % SHERS.length;
            p.edit().putInt("index", index).apply();
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            int[] ids = manager.getAppWidgetIds(new ComponentName(context, SherWidgetProvider.class));
            for (int id : ids) render(context, manager, id);
        }
    }

    private static void ensureDay(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String today = LocalDate.now(ZoneId.systemDefault()).toString();
        String saved = p.getString("day", "");
        if (!today.equals(saved)) {
            // Daily reset: the first sher is shown again each local calendar day.
            p.edit().putString("day", today).putInt("index", 0).apply();
        }
    }

    private static void render(Context context, AppWidgetManager manager, int widgetId) {
        ensureDay(context);
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int index = Math.floorMod(p.getInt("index", 0), SHERS.length);
        Sher sher = SHERS[index];
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_sher);
        views.setTextViewText(R.id.devanagari, sher.devanagari);
        views.setTextViewText(R.id.roman, sher.roman);
        views.setTextViewText(R.id.poet, "— " + sher.poet);
        views.setTextViewText(R.id.count, String.format(java.util.Locale.ROOT, "%02d / %02d", index + 1, SHERS.length));
        views.setTextViewText(R.id.source, "◫ REKHTA · OPEN SHER");
        views.setOnClickPendingIntent(R.id.next, actionIntent(context, ACTION_NEXT, 101));
        views.setOnClickPendingIntent(R.id.prev, actionIntent(context, ACTION_PREV, 102));
        Intent open = new Intent(Intent.ACTION_VIEW, Uri.parse(sher.url));
        PendingIntent openPi = PendingIntent.getActivity(context, 103, open,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.source, openPi);
        views.setOnClickPendingIntent(R.id.devanagari, actionIntent(context, ACTION_NEXT, 104));
        views.setOnClickPendingIntent(R.id.roman, actionIntent(context, ACTION_NEXT, 105));
        manager.updateAppWidget(widgetId, views);
    }

    private static PendingIntent actionIntent(Context context, String action, int requestCode) {
        Intent intent = new Intent(context, SherWidgetProvider.class);
        intent.setAction(action);
        return PendingIntent.getBroadcast(context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
