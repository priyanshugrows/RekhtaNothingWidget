# REKHTA × NOTHING — Android Home-screen Widget

A small native Android AppWidget concept for Nothing Phone (3): black card, red accents, Devanagari + Roman Urdu, poet credit, tap-to-cycle, and Rekhta source links.

## What this starter project does
- Shows one sher at a time.
- Tap the couplet or `›` to move to the next sher; tap `‹` to go back.
- Shows a `01 / 05` counter.
- Tapping `REKHTA · OPEN SHER` opens the corresponding Rekhta page.
- Resets to sher 1 on each new local calendar day.
- Android's widget update interval is set to 30 minutes, the platform minimum; the day check ensures a fresh daily reset.

## Important limitation
This is a source project, not an installed APK. It uses a small five-sher seed list, not a live scraper. The included entries have Rekhta source links; the widget does not download new poetry from Rekhta. A future version can add a larger curated, source-checked catalog and select a different five-shers-per-day set. Directly scraping Rekhta on-device is not included.

## Build and install
1. Install Android Studio on a computer and open this folder as a project.
2. Let Gradle sync. Use JDK 17 and Android SDK 35.
3. Choose **Build → Build APK(s)**.
4. Transfer the generated debug APK to your phone and install it. You may need to allow installation from that file manager.
5. Long-press the Nothing Phone (3) home screen → **Widgets** → **Rekhta × Nothing** → drag the widget onto the home screen.
6. Resize the widget to a wider card for best results.

## Customization
- Poetry and Rekhta URLs: `app/src/main/java/com/rekhta/nothingwidget/SherWidgetProvider.java`
- Widget layout: `app/src/main/res/layout/widget_sher.xml`
- Background/border: `app/src/main/res/drawable/widget_background.xml`
- Widget size/update interval: `app/src/main/res/xml/sher_widget_info.xml`

## Source links used for the seed catalog
- Faiz Ahmad Faiz: https://www.rekhta.org/couplets/dil-naa-umiid-to-nahiin-naakaam-hii-to-hai-faiz-ahmad-faiz-couplets
- Mirza Ghalib: https://www.rekhta.org/archives/2020-03-06/All/
- Shakeb Jalali: https://www.rekhta.org/authors/shakeb-jalali/
- Nida Fazli: https://www.rekhta.org/archives/2024-01-06/TopFive/
- Faiz Ahmad Faiz: https://www.rekhta.org/translators/faiz-ahmad-faiz/couplets

This is an unofficial fan-made design and is not affiliated with Nothing or Rekhta.
